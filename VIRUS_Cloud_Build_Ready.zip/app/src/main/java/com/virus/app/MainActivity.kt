package com.virus.app

import android.os.Bundle
import android.app.Activity
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF101014)
private val Panel = Color(0xFF1B1B22)
private val Red = Color(0xFFE53945)
private val Muted = Color(0xFFAAAAB4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VirusAuthApp(this) }
    }
}

@Composable
fun VirusAuthApp(activity: Activity) {
    val auth = remember { FirebaseAuth.getInstance() }
    var phone by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var screen by remember { mutableStateOf(if (auth.currentUser != null) "home" else "phone") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    val callbacks = remember {
        object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                auth.signInWithCredential(credential).addOnCompleteListener { task ->
                    busy = false
                    if (task.isSuccessful) {
                        screen = "home"
                        message = "تم التحقق من رقمك بنجاح"
                    } else {
                        message = task.exception?.localizedMessage ?: "تعذر تسجيل الدخول"
                    }
                }
            }

            override fun onVerificationFailed(e: FirebaseException) {
                busy = false
                message = e.localizedMessage ?: "فشل إرسال رمز التحقق"
            }

            override fun onCodeSent(
                id: String,
                token: PhoneAuthProvider.ForceResendingToken
            ) {
                verificationId = id
                busy = false
                screen = "otp"
                message = "تم إرسال رمز التحقق برسالة SMS"
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Red, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (screen) {
                "phone" -> PhoneScreen(
                    phone = phone,
                    onPhoneChange = { phone = it.filter(Char::isDigit).take(10) },
                    busy = busy,
                    message = message,
                    onSend = {
                        val normalized = phone.trim()
                        if (normalized.length !in 9..10) {
                            message = "أدخل رقم هاتف عراقي صحيحاً بدون +964"
                        } else {
                            val fullPhone = "+964" + normalized.removePrefix("0")
                            busy = true
                            message = "جارٍ إرسال رمز التحقق..."
                            val options = PhoneAuthOptions.newBuilder(auth)
                                .setPhoneNumber(fullPhone)
                                .setTimeout(60L, TimeUnit.SECONDS)
                                .setActivity(activity)
                                .setCallbacks(callbacks)
                                .build()
                            PhoneAuthProvider.verifyPhoneNumber(options)
                        }
                    }
                )
                "otp" -> OtpScreen(
                    otp = otp,
                    onOtpChange = { otp = it.filter(Char::isDigit).take(6) },
                    busy = busy,
                    message = message,
                    onVerify = {
                        val id = verificationId
                        if (id == null || otp.length != 6) {
                            message = "أدخل رمز التحقق المكوّن من 6 أرقام"
                        } else {
                            busy = true
                            val credential = PhoneAuthProvider.getCredential(id, otp)
                            auth.signInWithCredential(credential).addOnCompleteListener { task ->
                                busy = false
                                if (task.isSuccessful) {
                                    screen = "home"
                                    message = "تم تسجيل الدخول بنجاح"
                                } else {
                                    message = task.exception?.localizedMessage ?: "الرمز غير صحيح"
                                }
                            }
                        }
                    },
                    onBack = { screen = "phone"; message = ""; otp = "" }
                )
                else -> HomeScreen(
                    phoneNumber = auth.currentUser?.phoneNumber ?: "",
                    onSignOut = {
                        auth.signOut()
                        phone = ""
                        otp = ""
                        message = ""
                        screen = "phone"
                    }
                )
            }
        }
    }
}

@Composable
fun BrandHeader() {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier.size(76.dp).background(Red, RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("V", color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.Black)
        }
        Text("فايروس", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black,
            modifier = Modifier.padding(top = 12.dp))
        Text("V I R U S", color = Red, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PhoneScreen(
    phone: String,
    onPhoneChange: (String) -> Unit,
    busy: Boolean,
    message: String,
    onSend: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BrandHeader()
        Text("أهلاً بك في فايروس", color = Color.White, fontSize = 21.sp,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 34.dp))
        Text("سجّل رقم هاتفك للمتابعة", color = Muted, fontSize = 14.sp,
            modifier = Modifier.padding(top = 8.dp, bottom = 24.dp))
        OutlinedTextField(
            value = phone,
            onValueChange = onPhoneChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("رقم الهاتف العراقي") },
            leadingIcon = { Text("+964", color = Color.White, fontWeight = FontWeight.Bold) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Red, focusedLabelColor = Red,
                unfocusedBorderColor = Muted, focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )
        Button(
            onClick = onSend,
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().padding(top = 18.dp).height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Red),
            shape = RoundedCornerShape(13.dp)
        ) {
            if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White)
            else Text("إرسال رمز التحقق", fontWeight = FontWeight.Bold)
        }
        if (message.isNotBlank()) {
            Text(message, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 14.dp))
        }
        Text("سيصلك رمز تحقق برسالة SMS", color = Muted, fontSize = 11.sp,
            modifier = Modifier.padding(top = 26.dp))
    }
}

@Composable
fun OtpScreen(
    otp: String,
    onOtpChange: (String) -> Unit,
    busy: Boolean,
    message: String,
    onVerify: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BrandHeader()
        Text("تأكيد رقم الهاتف", color = Color.White, fontSize = 22.sp,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 34.dp))
        Text("أدخل رمز التحقق المرسل برسالة SMS", color = Muted, fontSize = 13.sp,
            modifier = Modifier.padding(top = 8.dp, bottom = 24.dp))
        OutlinedTextField(
            value = otp,
            onValueChange = onOtpChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("رمز التحقق") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Red, focusedLabelColor = Red,
                unfocusedBorderColor = Muted, focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )
        Button(
            onClick = onVerify,
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().padding(top = 18.dp).height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Red),
            shape = RoundedCornerShape(13.dp)
        ) {
            if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White)
            else Text("تأكيد ودخول", fontWeight = FontWeight.Bold)
        }
        TextButton(onClick = onBack) { Text("تغيير رقم الهاتف", color = Red) }
        if (message.isNotBlank()) {
            Text(message, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun HomeScreen(phoneNumber: String, onSignOut: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(22.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BrandHeader()
        Text("تم تسجيل الدخول بنجاح", color = Color.White, fontSize = 22.sp,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 32.dp))
        Text(phoneNumber, color = Muted, fontSize = 14.sp,
            modifier = Modifier.padding(top = 8.dp))
        Text("مرحباً بك في تطبيق فايروس | VIRUS", color = Muted,
            modifier = Modifier.padding(top = 18.dp))
        Button(onClick = onSignOut, modifier = Modifier.fillMaxWidth().padding(top = 28.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Red)) {
            Text("تسجيل الخروج")
        }
    }
}
