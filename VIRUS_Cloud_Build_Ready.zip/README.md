# فايروس | VIRUS — Android + Firebase Phone Auth

## بناء APK سحابياً من دون Termux
أُضيف GitHub Actions ليبني APK تجريبياً تلقائياً.

1. أنشئ مستودعاً جديداً في GitHub باسم `VIRUS-Android`.
2. ارفع محتويات هذا المجلد إلى المستودع واجعل الفرع `main`.
3. افتح تبويب Actions.
4. اختر Build VIRUS Android APK ثم Run workflow (أو انتظر بدء البناء بعد الرفع).
5. بعد نجاح البناء، افتح نتيجة التشغيل ثم Artifacts ونزّل `VIRUS-debug-APK`.
6. فك ضغط artifact وثبّت `app-debug.apk` على هاتف Android.

## إعداد Firebase قبل تجربة SMS
1. Firebase Console > Authentication > Sign-in method / Sign-in providers.
2. فعّل Phone واسمح بإرسال الرسائل إلى العراق (+964) في سياسة SMS / المناطق.
3. أضف بصمات SHA-1 وSHA-256 لتطبيق Android في Firebase.
4. اختبر أولاً بأرقام الاختبار في Firebase لتجنب استهلاك رسائل SMS.

## بيانات الربط
- Firebase project ID: `virus-f360b`
- Android package: `com.virus.app`
- ملف الإعداد: `app/google-services.json`

## تنبيه
هذه نسخة أولية لشاشة رقم الهاتف والتحقق SMS وصفحة ترحيب بعد الدخول. لا يوجد بعد نظام طلبات أو محفظة حقيقية أو قاعدة بيانات للمستخدمين أو لوحة إدارة أو دفع. الناتج Debug APK للتجربة وليس إصداراً نهائياً للنشر على Google Play.
